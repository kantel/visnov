/* global monogatari */

// Persistent Storage Variable
monogatari.storage ({
	p: {
		name: 'Jörg'
	}
});